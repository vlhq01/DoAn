package com.example.doan.DataSource

import androidx.annotation.DrawableRes

data class service(
    @DrawableRes
    val imageResourceId: Int
    )
