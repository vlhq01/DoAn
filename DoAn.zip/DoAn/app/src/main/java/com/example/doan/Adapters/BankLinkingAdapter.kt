package com.example.doan.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.doan.BankListFragment
import com.example.doan.DataSource.Banks
import com.example.doan.R
import java.util.ArrayList

class BankLinkingAdapter(private val context: BankListFragment,
                         private val dataset: ArrayList<Banks>?
) : RecyclerView.Adapter<BankLinkingAdapter.bankLinkingViewHolder>() {

    class bankLinkingViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {

        val imageView: ImageView = view.findViewById(R.id.imgBanks)
        val banksName: TextView = view.findViewById(R.id.tvBanksName)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BankLinkingAdapter.bankLinkingViewHolder {
        val adapterLayout = LayoutInflater.from(context.context)
            .inflate(R.layout.bankslistitem, parent, false)
        return BankLinkingAdapter.bankLinkingViewHolder(adapterLayout)
    }


    override fun onBindViewHolder(holder: bankLinkingViewHolder, position: Int) {
        val item = dataset?.get(position)
        if (item != null) {
            holder.imageView.setImageResource(item.imageResourceId)
        }
        if (item != null) {
            holder.banksName.setText(item.bankname)
        }
    }


    override fun getItemCount(): Int {
        return dataset?.size ?: 0
    }




}