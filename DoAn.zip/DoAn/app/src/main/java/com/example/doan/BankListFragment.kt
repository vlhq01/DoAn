package com.example.doan

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import com.example.doan.Adapters.BankLinkingAdapter
import com.example.doan.DataSource.Banks
import com.example.doan.DataSource.service

import com.example.doan.databinding.BanklistBinding


class BankListFragment : Fragment() {
    private var _binding: BanklistBinding?=null
    private val binding get() = _binding!!

    var dataset: java.util.ArrayList<Banks>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = BanklistBinding.inflate(inflater,container,false)
        initData()

        binding.banklistrecyclerview.layoutManager = GridLayoutManager(this.context,4)
        binding.banklistrecyclerview.adapter = BankLinkingAdapter(this,dataset)


        val view = binding.root

        return view
    }

    private fun initData() {
        dataset = ArrayList<Banks>()
        dataset!!.add(Banks(R.drawable.bidv, "BIDV"))
        dataset!!.add(Banks(R.drawable.viettinbank, "Viettinbank"))
        dataset!!.add(Banks(R.drawable.vietcambank, "Vietcombank"))
        dataset!!.add(Banks(R.drawable.agribank, "Agribank"))

    }
}