package com.example.doan.DataSource

import com.example.doan.R

class serviceDatasource {
    fun loadServices(): List<service> {
        return listOf<service>(
            service(R.drawable.shopeepayicon),
            service(R.drawable.shopeeicon),
            service(R.drawable.lazada),
            service(R.drawable.momoicon),
            service(R.drawable.vnpayicon),
            service(R.drawable.zalopayicon),
        )


    }
}