package com.example.doan

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doan.Adapters.notificationsAdapter
import com.example.doan.DataSource.Contacts
import com.example.doan.DataSource.Datasource
import com.example.doan.databinding.NotificationsFragmentBinding

class NotificationsFragment : Fragment() {

    private var _binding: NotificationsFragmentBinding?=null
    private val binding get() = _binding!!
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)


    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = NotificationsFragmentBinding.inflate(inflater,container,false)
        val view = binding.root
        val dataset = Datasource().loadNotifications()
        binding.notificationRecyclerview.setNestedScrollingEnabled(false)
        binding.notificationRecyclerview.layoutManager = LinearLayoutManager(this.context,LinearLayoutManager.VERTICAL,false)
        binding.notificationRecyclerview.adapter = notificationsAdapter(this,dataset)
        return view
    }
}