package com.example.doan


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.example.doan.DataSource.serviceDatasource
import com.example.doan.databinding.WalletfragmentBinding
import com.google.android.material.bottomsheet.BottomSheetDialog


class WalletFragment : Fragment() {
    private var _binding: WalletfragmentBinding?=null
    private val binding get() = _binding!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = WalletfragmentBinding.inflate(inflater,container,false)
        val dataset = serviceDatasource().loadServices()

        binding.add.setOnClickListener(View.OnClickListener { showBottomSheetDialog() })
        val view = binding.root

        return view
    }


    private fun showBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(this.requireContext())
        bottomSheetDialog.setContentView(R.layout.linkingmethods_bottomsheetdialog)

        val bankaccountlayout = bottomSheetDialog.findViewById<LinearLayout>(R.id.BankaccountLinearLaySout)
        if (bankaccountlayout != null) {
            bankaccountlayout.setOnClickListener{
                val action = WalletFragmentDirections.actionWalletFragmentToBankListFragment()
                view?.findNavController()?.navigate(action)
            }
        }
        bottomSheetDialog.show()

    }

}