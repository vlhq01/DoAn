package com.example.doan.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.doan.DataSource.noti
import com.example.doan.DataSource.service
import com.example.doan.MainFragment
import com.example.doan.NotificationsFragment
import com.example.doan.R

class homeServiceAdapter(private val context: MainFragment,
                         private val dataset: List<service>) : RecyclerView.Adapter<homeServiceAdapter.serviceItemViewHolder>() {

    class serviceItemViewHolder(private val view: View) : RecyclerView.ViewHolder(view) {

        val imageView: ImageView = view.findViewById(R.id.imgservice)

    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): serviceItemViewHolder {
        val adapterLayout = LayoutInflater.from(context.context)
            .inflate(R.layout.homeservice_recycler_item, parent, false)
        return homeServiceAdapter.serviceItemViewHolder(adapterLayout)
    }


    override fun getItemCount(): Int {
        return dataset.size
    }


    override fun onBindViewHolder(holder: serviceItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.imageView.setImageResource(item.imageResourceId)
    }


}
