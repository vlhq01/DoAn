package com.example.doan

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

import androidx.navigation.findNavController

import androidx.recyclerview.widget.GridLayoutManager

import com.example.doan.Adapters.homeServiceAdapter

import com.example.doan.DataSource.serviceDatasource
import com.example.doan.databinding.MainFragmentBinding

class MainFragment : Fragment() {
    private var _binding: MainFragmentBinding?=null
    private val binding get() = _binding!!
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = MainFragmentBinding.inflate(inflater,container,false)
        val dataset = serviceDatasource().loadServices()
        binding.servicesRecyclerview.setNestedScrollingEnabled(false)
        binding.servicesRecyclerview.layoutManager = GridLayoutManager(this.context,4)
        binding.servicesRecyclerview.adapter = homeServiceAdapter(this,dataset)
        binding.imgTopUp.setOnClickListener{
            val action = MainFragmentDirections.actionMainFragmentToMoneyInputFragment()
            view?.findNavController()?.navigate(action)
        }
        binding.imgTransfer.setOnClickListener{
            val action2 = MainFragmentDirections.actionMainFragmentToContactsListFragment()
            view?.findNavController()?.navigate(action2)
        }
        binding.imgWallet.setOnClickListener{
            val action3 = MainFragmentDirections.actionMainFragmentToWalletFragment()
            view?.findNavController()?.navigate(action3)
        }
        val view = binding.root

        return view
    }
}