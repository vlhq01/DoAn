package com.example.doan.DataSource

import androidx.annotation.DrawableRes

data class Banks(
    @DrawableRes
    val imageResourceId: Int,

    val bankname: String
)