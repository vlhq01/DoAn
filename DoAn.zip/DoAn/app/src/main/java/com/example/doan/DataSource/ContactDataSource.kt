package com.example.doan.DataSource

import com.example.doan.R

class ContactDataSource {
    fun loadContact(): List<Contacts> {
        return listOf<Contacts>(
           Contacts(3,"dfgdfggfrg","346356546546")
        )


    }

}