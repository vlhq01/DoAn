package com.example.doan



import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import com.example.doan.databinding.MoneytransferFragmentBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.bottomsheet.BottomSheetDialog
import `in`.aabhasjindal.otptextview.OTPListener
import `in`.aabhasjindal.otptextview.OtpTextView


class MoneyTransferFragment : Fragment(){
    private var _binding: MoneytransferFragmentBinding? =null
    private val binding get() = _binding!!

    private lateinit var receiverName: String
    private lateinit var receiverPhone: String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments.let {
            if (it != null) {
                receiverName = it.getString("name").toString()
                receiverPhone =  it.getString("phone").toString()
            }
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = MoneytransferFragmentBinding.inflate(inflater,container,false)
        val view = binding.root
        binding.txtReceiverTransferName.setText(receiverName)
        binding.txtReceiverTransferPhone.setText(receiverPhone)
        activity?.actionBar?.setTitle("Transfer")
        var navBar = activity?.findViewById<BottomNavigationView>(R.id.bottomnavigation)
        if (navBar != null) {
            navBar.isVisible = false
        }
        binding.btnTransfer.setOnClickListener(View.OnClickListener { showBottomSheetDialog() })
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

    }


    private fun showBottomSheetDialog() {
        val bottomSheetDialog = BottomSheetDialog(this.requireContext())
        bottomSheetDialog.setContentView(R.layout.password_bottomsheetdialod)
        val otpTextView: OtpTextView
        otpTextView = bottomSheetDialog.findViewById<OtpTextView>(R.id.otp_view)!!
        otpTextView.otpListener = object : OTPListener {
            override fun onInteractionListener() {
              otpTextView.requestFocusOTP()
            }

            override fun onOTPComplete(otp: String) {
                otpTextView.requestFocusOTP()
                Toast.makeText(requireContext(),"otp inputed",Toast.LENGTH_LONG).show()
                bottomSheetDialog.dismiss()
            }
        }
        bottomSheetDialog.show()

    }

}

